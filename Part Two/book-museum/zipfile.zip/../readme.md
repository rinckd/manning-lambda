```
aws iam create-role --role-name manning-lambda-role --assume-role-policy-document file://trust-policy.json

aws iam attach-role-policy --policy-arn
arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole --role-name manning-lambda-role
```
